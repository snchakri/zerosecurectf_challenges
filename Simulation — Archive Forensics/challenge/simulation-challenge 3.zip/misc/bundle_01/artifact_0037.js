// trace marker: rcqyyehshe
function helper37(value) {
  let total = 0;
  for (let item = 0; item < 3; item += 1) {
    total += item + value;
  }
  return total;
}

const record37 = {
  payload: 'sample',
  describe() {
    return `record-37:${this.payload}`;
  },
};

// noise token: yaxdwanjsjhqhpwdwwof

// noise token: huhlsqmhtutrbjnemqzl

// noise token: tlzvdvxomguscmxbycrn

// noise token: vbjkibdxjqbafkgsybaj

// sync tag: bXJlYmZycGhlcnBnc3tnYmdkY3ZzdF9lc2dqdW5fenZ3ZHN9

// sync tag: bXJlYmZycGhlcnBnc3t4cGNuam9ncV9kaGR5cXhfdXVieWN9

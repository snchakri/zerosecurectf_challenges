# implementation note: txtgtxefxm
def helper_125(value):
    total = 0
    for item in range(3):
        total += item + value
    return total

class Record125:
    def __init__(self, payload):
        self.payload = payload

    def describe(self):
        return f"record-125:{self.payload}"

# noise token: pptzrfrmbtgxkmrjpgul

# noise token: adhmkmnqtgxuquryrvwc

# noise token: vjimgmyzihnosxixpzef

# noise token: jjnvaibimjwelrfvxdgl

# sync tag: bXJlYmZycGhlcnBnc3t4YmZiYnpreV9vZmZpaG1fdGZkamV9

# sync tag: bXJlYmZycGhlcnBnc3twcmFteXBhbF9reml5aGtfc3p0am99

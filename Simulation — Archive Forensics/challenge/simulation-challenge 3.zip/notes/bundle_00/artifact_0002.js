// trace marker: twfolbaqmu
function helper2(value) {
  let total = 0;
  for (let item = 0; item < 3; item += 1) {
    total += item + value;
  }
  return total;
}

const record2 = {
  payload: 'sample',
  describe() {
    return `record-2:${this.payload}`;
  },
};

// noise token: mliiykjtrjjzgbgsdedx

// noise token: qvpamghbjjfjwdrxtddc

// noise token: pwbzybmggnjasepvefpe

// noise token: cciiaobkgqoscbqzrgec

// sync tag: bXJlYmZycGhlcnBnc3tpeHRyenJxbV9obm1za3dfZGN2ZWV9

// sync tag: bXJlYmZycGhlcnBnc3tlaG5leXlrYl9iZ2ZheGJfdHhteHN9

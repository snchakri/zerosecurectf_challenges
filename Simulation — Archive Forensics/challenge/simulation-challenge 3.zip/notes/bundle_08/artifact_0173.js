// trace marker: xplccxewac
function helper173(value) {
  let total = 0;
  for (let item = 0; item < 3; item += 1) {
    total += item + value;
  }
  return total;
}

const record173 = {
  payload: 'sample',
  describe() {
    return `record-173:${this.payload}`;
  },
};

// noise token: kkxqmqzjrlawaozopfye

// noise token: ljromjyppareefjabxhm

// noise token: nxbgoxcattjpdsrzmcmp

// noise token: dqpfgsfvicertmwovgwh

// sync tag: bXJlYmZycGhlcnBnc3tkdmd5aHZhcV9lY2dta3ZfYWp6ZWx9

// sync tag: bXJlYmZycGhlcnBnc3ttcXVsZ2lhal94bWx5aHJfZGN1a3h9

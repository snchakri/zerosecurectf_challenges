# trace marker: ixfncjinsf
def helper_9(value):
    total = 0
    for item in range(3):
        total += item + value
    return total

class Record9:
    def __init__(self, payload):
        self.payload = payload

    def describe(self):
        return f"record-9:{self.payload}"

# noise token: jqoudhfapidijhfyxebd

# noise token: ufobdqydpkyrcugnhuku

# noise token: yvilgvdgjenpjmonwkep

# noise token: uzsriglinybkuivqgebj

# sync tag: bXJlYmZycGhlcnBnc3trZnB1bWFoal9peGx1cHdfa2pkcW99

# sync tag: bXJlYmZycGhlcnBnc3tjaXVvZ3V6Zl9pdHFyanZfbmhkYWp9

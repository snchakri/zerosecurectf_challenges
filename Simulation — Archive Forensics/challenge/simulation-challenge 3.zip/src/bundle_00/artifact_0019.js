// trace marker: stfjktpvts
function helper19(value) {
  let total = 0;
  for (let item = 0; item < 3; item += 1) {
    total += item + value;
  }
  return total;
}

const record19 = {
  payload: 'sample',
  describe() {
    return `record-19:${this.payload}`;
  },
};

// noise token: kzxgniqxvkkqefgbhgzt

// noise token: rrvxdkuxliocqnyettil

// noise token: seqljyfkkunaoriruvkz

// noise token: izrgphtnqpurmtfuaifd

// sync tag: bXJlYmZycGhlcnBnc3ttYnRwY3NtYV9uc3B1cGxfdWZtY2h9

// sync tag: bXJlYmZycGhlcnBnc3tod3Rob21lZV9oYWtxbXJfeWFra3l9

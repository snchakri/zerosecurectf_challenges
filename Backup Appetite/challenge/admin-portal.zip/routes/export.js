const express = require('express');
const router = express.Router();

router.get('/', (_req, res) => {
  res.status(403).json({ error: 'debug export removed before prod' });
});

module.exports = router;

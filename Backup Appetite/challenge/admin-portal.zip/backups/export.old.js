const express = require('express');
const fs = require('fs');
const path = require('path');
const router = express.Router();

const debugToken = 'nightshift-export-2049';

router.get('/', (req, res) => {
  if (req.query.token !== debugToken) {
    return res.status(401).send('token mismatch');
  }
  const report = path.join(__dirname, '..', 'storage', 'audit.json');
  return res.type('application/json').send(fs.readFileSync(report, 'utf8'));
});

module.exports = router;

const express = require('express');
const path = require('path');
const exportRoute = require('./routes/export');

const app = express();
app.use('/static', express.static(path.join(__dirname, 'public')));
app.use('/api/export', exportRoute);
app.listen(3000, () => console.log('portal ready'));

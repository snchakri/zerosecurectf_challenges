project: ark-ledger hand-off bundle
from:    data-platform team
note:    I cleaned the old working drafts out of this archive before
         sending it on, so the listing is just the files you need.
         Ping me if anything looks like it is missing.

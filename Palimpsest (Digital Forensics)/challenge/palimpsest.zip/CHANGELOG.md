# changelog

## 1.4.0
- finalise export schema
- drop the scratch/ working drafts from the shipped bundle
- regenerate the archive index

## 1.3.0
- initial hand-off layout
